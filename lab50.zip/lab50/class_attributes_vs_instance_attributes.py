class A:
	id = 1
	def __init__(self, name):
		self.name  = name


a = A("Ada")
print(a.name)
print(A.id)
print(a.id)



